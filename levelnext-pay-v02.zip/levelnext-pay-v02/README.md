# LEVELNEXT PAY — versão 0.2

Identidade confirmada:
- Nome: LEVELNEXT PAY
- Plataforma inicial: Android
- Cartões planejados: virtual e físico, sujeitos ao parceiro emissor
- Público: público geral

## Conteúdo
- `android/`: aplicativo Android em Kotlin + Jetpack Compose, com telas demonstrativas de Início, Pix, Cartões e Perfil.
- `backend/`: API Kotlin/Spring Boot de desenvolvimento e modelo inicial de ledger.

## Instalação
Abra a pasta `android` no Android Studio, aguarde a sincronização do Gradle e execute em emulador ou aparelho.
Para a API, consulte `backend/README.md`.

## Limites importantes
Esta versão não abre conta, não valida CPF, não movimenta saldo, não envia Pix e não emite cartões. Os cartões e saldos são ilustrativos. A integração real exige contrato com instituição autorizada, documentação empresarial, análise de risco/compliance, homologação e liberação formal do parceiro.

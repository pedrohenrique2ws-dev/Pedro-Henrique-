package br.com.levelnext.api

import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import java.time.Instant

@RestController
@RequestMapping("/api/v1")
class StatusController {
    @GetMapping("/status")
    fun status() = mapOf(
        "service" to "LEVELNEXT API",
        "status" to "development",
        "timestamp" to Instant.now().toString(),
        "financial_operations_enabled" to false,
        "message" to "Ambiente de desenvolvimento. Nenhuma operação financeira real é executada."
    )
}

package br.com.levelnext.api

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class LevelNextApiApplication

fun main(args: Array<String>) {
    runApplication<LevelNextApiApplication>(*args)
}

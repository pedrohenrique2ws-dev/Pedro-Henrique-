package br.com.levelnext.api

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

class StatusControllerTest {
    @Test
    fun `development status does not enable financial operations`() {
        val response = StatusController().status()
        assertEquals(false, response["financial_operations_enabled"])
        assertEquals("development", response["status"])
    }
}

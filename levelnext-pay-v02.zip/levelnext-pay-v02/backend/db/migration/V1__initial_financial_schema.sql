-- Modelo inicial para revisão técnica. Não executar em produção sem revisão.
-- Valores monetários são armazenados em centavos (BIGINT), nunca em FLOAT.
CREATE TABLE customers (
    id UUID PRIMARY KEY,
    external_customer_ref VARCHAR(120) NOT NULL UNIQUE,
    status VARCHAR(24) NOT NULL CHECK (status IN ('PENDING_KYC','ACTIVE','RESTRICTED','CLOSED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE payment_accounts (
    id UUID PRIMARY KEY,
    customer_id UUID NOT NULL REFERENCES customers(id),
    provider_account_ref VARCHAR(160) UNIQUE,
    currency CHAR(3) NOT NULL DEFAULT 'BRL',
    status VARCHAR(24) NOT NULL CHECK (status IN ('PENDING','ACTIVE','BLOCKED','CLOSED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Ledger de dupla entrada: cada journal_entry deve fechar em zero por moeda.
CREATE TABLE ledger_accounts (
    id UUID PRIMARY KEY,
    payment_account_id UUID REFERENCES payment_accounts(id),
    account_code VARCHAR(40) NOT NULL,
    currency CHAR(3) NOT NULL DEFAULT 'BRL',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE journal_entries (
    id UUID PRIMARY KEY,
    idempotency_key VARCHAR(120) NOT NULL UNIQUE,
    provider_transaction_ref VARCHAR(160),
    description VARCHAR(240) NOT NULL,
    status VARCHAR(16) NOT NULL CHECK (status IN ('PENDING','POSTED','REVERSED','FAILED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE ledger_postings (
    id UUID PRIMARY KEY,
    journal_entry_id UUID NOT NULL REFERENCES journal_entries(id),
    ledger_account_id UUID NOT NULL REFERENCES ledger_accounts(id),
    amount_cents BIGINT NOT NULL CHECK (amount_cents <> 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_accounts_customer ON payment_accounts(customer_id);
CREATE INDEX idx_postings_entry ON ledger_postings(journal_entry_id);

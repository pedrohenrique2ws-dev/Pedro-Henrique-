# LEVELNEXT API — ambiente de desenvolvimento

API inicial em Kotlin + Spring Boot. Neste momento, apenas expõe um endpoint de status; não cria contas bancárias, não consulta saldos reais e não executa Pix.

## Requisitos
- JDK 21
- Gradle 8.10+ (ou importar no IntelliJ IDEA/Android Studio com suporte a Gradle)

## Executar
Na pasta `backend`:
```bash
gradle bootRun
```
Teste:
```bash
curl http://localhost:8080/api/v1/status
```

## Modelo de dados
`db/migration/V1__initial_financial_schema.sql` é um rascunho de esquema com clientes, contas referenciadas no provedor e ledger de dupla entrada. Ainda não está conectado a banco de dados nem a um provedor.

## Antes de produção
Adicionar autenticação OIDC/OAuth2, autorização por escopo, PostgreSQL, migrações versionadas, cofre de segredos, TLS, rate limiting, idempotência, assinatura/verificação de webhooks, trilha de auditoria imutável, monitoramento, backups, recuperação de desastre, testes de invasão e revisão independente. Nunca confiar em saldo calculado pelo aplicativo.

A integração financeira só deve ser ativada após contrato formal, avaliação de conformidade e liberação técnica do parceiro autorizado. O app deve identificar claramente a instituição prestadora de BaaS, conforme a regulamentação aplicável.

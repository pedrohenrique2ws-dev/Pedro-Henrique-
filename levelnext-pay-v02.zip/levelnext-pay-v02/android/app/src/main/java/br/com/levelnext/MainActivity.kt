package br.com.levelnext

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF0D1220)
private val Panel = Color(0xFF192338)
private val Panel2 = Color(0xFF24314A)
private val Violet = Color(0xFF8065FF)
private val Muted = Color(0xFFA5B1C7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LevelNextPayApp() }
    }
}

@Composable
fun LevelNextPayApp() {
    var selected by remember { mutableStateOf("Início") }
    var balanceVisible by remember { mutableStateOf(true) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Violet, background = Ink, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    val destinations = listOf(
                        Triple("Início", Icons.Rounded.Home, "Início"),
                        Triple("Pix", Icons.Rounded.QrCode, "Pix"),
                        Triple("Cartões", Icons.Rounded.CreditCard, "Cartões"),
                        Triple("Perfil", Icons.Rounded.Person, "Perfil")
                    )
                    destinations.forEach { (label, icon, route) ->
                        NavigationBarItem(
                            selected = selected == route,
                            onClick = { selected = route },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                BrandHeader()
                when (selected) {
                    "Pix" -> PixScreen()
                    "Cartões" -> CardsScreen()
                    "Perfil" -> ProfileScreen()
                    else -> HomeScreen(balanceVisible) { balanceVisible = !balanceVisible }
                }
            }
        }
    }
}

@Composable
private fun BrandHeader() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).background(Violet, RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center) {
            Text("L", fontSize = 26.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(12.dp))
        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text("LEVELNEXT PAY", fontWeight = FontWeight.Black, fontSize = 18.sp, letterSpacing = 0.4.sp)
            Text("SUA VIDA FINANCEIRA EM OUTRO NÍVEL", color = Muted, fontSize = 8.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable
private fun HomeScreen(balanceVisible: Boolean, toggleBalance: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Column(
            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(24.dp)).padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("SALDO DISPONÍVEL", color = Muted, fontSize = 11.sp, letterSpacing = 1.4.sp)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = toggleBalance, modifier = Modifier.size(28.dp)) {
                    Icon(if (balanceVisible) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff,
                        contentDescription = "Mostrar ou ocultar saldo", tint = Muted)
                }
            }
            Text(if (balanceVisible) "R$ 0,00" else "••••••",
                fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Text("Conta demonstrativa • sem movimentação real", color = Muted, fontSize = 10.sp)
        }
        Text("Atalhos", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            HomeAction("Pix", Icons.Rounded.QrCode, Modifier.weight(1f))
            HomeAction("Transferir", Icons.Rounded.SwapHoriz, Modifier.weight(1f))
            HomeAction("Pagar", Icons.Rounded.ReceiptLong, Modifier.weight(1f))
            HomeAction("Cartão", Icons.Rounded.CreditCard, Modifier.weight(1f))
        }
        Text("Movimentações", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Tudo tranquilo por aqui", fontWeight = FontWeight.SemiBold)
                Text("Seu histórico aparecerá quando a conta estiver conectada a uma instituição financeira parceira.",
                    color = Muted, fontSize = 12.sp)
            }
        }
        DemoNotice()
    }
}

@Composable
private fun HomeAction(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(16.dp)).padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(icon, contentDescription = title, tint = Violet)
        Text(title, fontSize = 10.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun PixScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Pix", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Envie e receba dinheiro de forma simples.", color = Muted, fontSize = 13.sp)
        FeatureTile(Icons.Rounded.Send, "Enviar Pix", "Transferência instantânea (indisponível na versão demonstrativa)")
        FeatureTile(Icons.Rounded.QrCodeScanner, "Pagar com QR Code", "Leitura de QR Code será integrada após contratação e homologação")
        FeatureTile(Icons.Rounded.ContentCopy, "Pix copia e cola", "Área preparada para integração com o provedor")
        FeatureTile(Icons.Rounded.Key, "Minhas chaves", "Cadastro e gerenciamento de chaves após ativação da conta")
        DemoNotice()
    }
}

@Composable
private fun CardsScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Meus cartões", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Box(Modifier.fillMaxWidth().height(205.dp)
            .background(Color(0xFF30275F), RoundedCornerShape(24.dp)).padding(22.dp)) {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("LEVELNEXT PAY", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Rounded.Contactless, contentDescription = "Aproximação")
                }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("••••  ••••  ••••  0000", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                    Row(verticalAlignment = Alignment.Bottom) {
                        Column {
                            Text("TITULAR DO CARTÃO", color = Color.LightGray, fontSize = 8.sp)
                            Text("NOME DO CLIENTE", fontSize = 11.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        Text("VISA / MASTERCARD*", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Text("Cartão conceitual. Número, bandeira e emissão dependem do parceiro emissor.", color = Muted, fontSize = 11.sp)
        FeatureTile(Icons.Rounded.CreditCard, "Cartão virtual", "Preparado para emissão pelo parceiro")
        FeatureTile(Icons.Rounded.LocalShipping, "Cartão físico", "Entrega e acompanhamento após contratação")
        DemoNotice()
    }
}

@Composable
private fun ProfileScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Meu perfil", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        FeatureTile(Icons.Rounded.Person, "Dados pessoais", "Cadastro e validação de identidade serão integrados")
        FeatureTile(Icons.Rounded.Security, "Segurança", "Biometria, autenticação reforçada e gestão de dispositivos")
        FeatureTile(Icons.Rounded.SupportAgent, "Ajuda e suporte", "Canais oficiais serão configurados antes do lançamento")
        FeatureTile(Icons.Rounded.Description, "Documentos e contratos", "Termos, tarifas e informações da instituição parceira")
        DemoNotice()
    }
}

@Composable
private fun FeatureTile(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, description: String) {
    Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = Violet, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(14.dp))
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(description, color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun DemoNotice() {
    Surface(color = Panel2, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Info, contentDescription = null, tint = Violet)
            Spacer(Modifier.width(9.dp))
            Text("Ambiente demonstrativo. Nenhuma operação financeira real está habilitada.",
                color = Color(0xFFD6DDF0), fontSize = 10.sp)
        }
    }
}

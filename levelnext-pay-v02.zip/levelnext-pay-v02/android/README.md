# LEVELNEXT — Android starter

Aplicativo Android inicial em Kotlin + Jetpack Compose. Este repositório contém somente a camada visual inicial; não é um banco operacional e não movimenta dinheiro.

## Requisitos
- Android Studio recente
- JDK 17
- Android SDK 35
- Gradle Wrapper gerado pelo Android Studio (File > Sync Project with Gradle Files)

## Abrir
1. Extraia o ZIP.
2. Abra a pasta `levelnext-android` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Execute em emulador ou aparelho Android.

## Estado atual
- Identidade visual LEVELNEXT
- Tela inicial demonstrativa
- Ocultar/mostrar saldo
- Navegação visual
- Atalhos de Pix, transferência, pagamento e cartão (ainda sem operações)

## Arquitetura necessária antes de produção
O app não deve guardar saldo nem decidir se uma transferência foi concluída. O backend deve ser a fonte de verdade e integrar-se ao ledger e ao provedor financeiro contratado.

Próximos serviços:
- API de identidade/KYC e gestão de consentimentos
- API de contas e ledger de dupla entrada
- Orquestrador Pix com idempotência, consulta de status e webhooks assinados
- Serviço de cartões/tokenização
- Antifraude, limites, trilhas de auditoria e monitoramento
- Painel administrativo com segregação de funções

## Segurança e conformidade
Antes de aceitar clientes ou dinheiro real, contratar instituição financeira/de pagamento habilitada e formalizar o modelo de atuação. O parceiro deverá confirmar quais produtos, contas, Pix, cartões, KYC e responsabilidades regulatórias estão cobertos pelo contrato. Não armazene senhas, chaves privadas, PAN/CVV ou credenciais bancárias no app. Use TLS, armazenamento seguro do sistema, tokens curtos, rotação de segredos no servidor, logs sem dados sensíveis e testes de segurança.

O Pix real depende de integração contratual com participante habilitado e dos requisitos aplicáveis do Banco Central. Consulte:
- https://www.bcb.gov.br/estabilidadefinanceira/participantespix
- https://www.bcb.gov.br/estabilidadefinanceira/instituicaopagamento
- https://www.bcb.gov.br/meubc/faqs/s/autorizacao-para-funcionamento

## Aviso
Não use dados fictícios como saldo real, nem habilite botões de transação sem integração homologada em ambiente de testes e aprovação do parceiro.
